const { McpServer } = require("@modelcontextprotocol/sdk/server/mcp.js");
const { StdioServerTransport } = require("@modelcontextprotocol/sdk/server/stdio.js");
const { z } = require("zod");

const server = new McpServer({
  name: "order-manager-mcp",
  version: "1.0.0"
});

// Get order status
server.tool(
  "get_order_status",
  "Get the status of an order",
  {
    orderId: z.string()
  },
  async ({ orderId }) => {

    // Dummy data for now
    const order = {
      orderId: orderId,
      status: "Shipped",
      trackingId: "TRK123456",
      expectedDelivery: "30 September 2026"
    };

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(order, null, 2)
        }
      ]
    };
  }
);

// Search products
server.tool(
  "search_products",
  "Search products",
  {
    productName: z.string()
  },
  async ({ productName }) => {

    const products = [
      {
        id: PR001,
        name: "iPhone 17",
        price: 79999,
        stock: 10
      },
      {
        id: PR002,
        name: "Samsung Galaxy",
        price: 69999,
        stock: 5
      },
      {
        id: PR003,
        name: "MacBook Pro",
        price: 149999,
        stock: 3
      }
    ];

    const result = products.filter(product =>
      product.name
        .toLowerCase()
        .includes(productName.toLowerCase())
    );

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2)
        }
      ]
    };
  }
);

// Cancel order
server.tool(
  "cancel_order",
  "Cancel an order",
  {
    orderId: z.string(),
    reason: z.string()
  },
  async ({ orderId, reason }) => {

    return {
      content: [
        {
          type: "text",
          text: `Order ${orderId} cancelled successfully. Reason: ${reason}`
        }
      ]
    };
  }
);

// Start MCP server
async function main() {
  const transport = new StdioServerTransport();

  await server.connect(transport);
}

main().catch(error => {
  console.error("MCP Server Error:", error);
  process.exit(1);
});