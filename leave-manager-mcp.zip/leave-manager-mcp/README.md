1. ..........Prerequisites.................

Make sure you have:

Node.js installed
npm installed
Claude Desktop installed
Basic knowledge of JavaScript

Check Node.js:

node --version

Check npm:

npm --version

2. ......Create the Project..................

Create a project folder:

mkdir leave-manager-mcp
cd leave-manager-mcp

Initialize npm:

npm init -y

3. .........Install Dependencies......................

Install the MCP SDK and Zod:

npm install @modelcontextprotocol/sdk zod


4. ......Configure ES Modules...........

Open package.json and add:

{
  "type": "module"
}

Example:

{
  "name": "leave-manager-mcp",
  "version": "1.0.0",
  "type": "module",
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.0",
    "zod": "^3.0.0"
  }
}


5. ....Create index.js.........

Create:

index.js

Example MCP server:

import { McpServer, ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

// In-memory mock database
const employeeLeaves = {
  E001: {
    balance: 18,
    history: ["2024-12-25", "2025-01-01"],
  },
  E002: {
    balance: 20,
    history: [],
  },
};

// Create MCP server
const mcp = new McpServer({
  name: "LeaveManager",
  version: "1.0.0",
});

// Tool: Check Leave Balance
mcp.tool(
  "get_leave_balance",
  "Check how many leave days are left for the employee",
  {
    employee_id: z.string(),
  },
  async ({ employee_id }) => {
    const data = employeeLeaves[employee_id];

    const text = data
      ? `${employee_id} has ${data.balance} leave days remaining.`
      : "Employee ID not found.";

    return {
      content: [
        {
          type: "text",
          text,
        },
      ],
    };
  }
);

// Tool: Apply for Leave

so on 

7. ......Test the MCP Server.........

Go to the project directory:

cd /Users/admin/Desktop/SUSHANTA/leave-manager-mcp

Run:

node index.js

The terminal may appear to wait without showing anything.

This is normal because the server is using:

StdioServerTransport

The MCP server is waiting for an MCP client such as Claude Desktop to communicate with it.

Stop it with:

Ctrl + C


8. ..........Configure Claude Desktop....................

Claude Desktop needs to know how to start the MCP server.

The configuration file on macOS is:

~/Library/Application Support/Claude/claude_desktop_config.json

This file is not inside the MCP project.

The two locations are separate:

MCP Project
/Users/admin/Desktop/SUSHANTA/leave-manager-mcp/
│
└── index.js

and:

Claude Configuration
~/Library/Application Support/Claude/
│
└── claude_desktop_config.json


9. ......Create Claude Configuration File..............

If the file does not exist:

touch ~/Library/Application\ Support/Claude/claude_desktop_config.json

Open it:

open -e ~/Library/Application\ Support/Claude/claude_desktop_config.json


10. .........Add MCP Server Configuration..............

Add:

{
  "mcpServers": {
    "leave-manager": {
      "command": "node",
      "args": [
        "/Users/admin/Desktop/SUSHANTA/leave-manager-mcp/index.js"
      ]
    }
  }
}
Important

The path must point to your actual index.js.

You can find your project path by running:

cd /Users/admin/Desktop/SUSHANTA/leave-manager-mcp
pwd

For example:

/Users/admin/Desktop/SUSHANTA/leave-manager-mcp

Then add:

/index.js

to get:

/Users/admin/Desktop/SUSHANTA/leave-manager-mcp/index.js


11. .......Verify Claude Configuration............

Run:

cat ~/Library/Application\ Support/Claude/claude_desktop_config.json

Expected configuration:

{
  "mcpServers": {
    "leave-manager": {
      "command": "node",
      "args": [
        "/Users/admin/Desktop/SUSHANTA/leave-manager-mcp/index.js"
      ]
    }
  }
}


12. create claude_desktop_config.json file

cat ~/Library/Application\ Support/Claude/claude_desktop_config.json
{
  "mcpServers": {
    "leave-manager": {
      "command": "node",
      "args": ["/Users/admin/Desktop/SUSHANTA/leave-manager-mcp/index.js"]
    }
  }
}

13. Open claude_desktop_config.json file

open -e ~/Library/Application\ Support/Claude/claude_desktop_config.json