import { McpServer, ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

// In-memory mock database with leave days to start
const employeeLeaves = {
  E001: { balance: 18, history: ["2024-12-25", "2025-01-01"] },
  E002: { balance: 20, history: [] },
};

// Create MCP server
const mcp = new McpServer({
  name: "LeaveManager",
  version: "1.0.0",
});

// Tool: Check Leave Balance
mcp.tool(
  "get_leave_balance",
  "Check how many leave days are left for the employee",
  {
    employee_id: z.string(),
  },
  async ({ employee_id }) => {
    const data = employeeLeaves[employee_id];
    const text = data
      ? `${employee_id} has ${data.balance} leave days remaining.`
      : "Employee ID not found.";
    return { content: [{ type: "text", text }] };
  }
);

// Tool: Apply for Leave with specific dates
mcp.tool(
  "apply_leave",
  'Apply leave for specific dates (e.g., ["2025-04-17", "2025-05-01"])',
  {
    employee_id: z.string(),
    leave_dates: z.array(z.string()),
  },
  async ({ employee_id, leave_dates }) => {
    if (!employeeLeaves[employee_id]) {
      return { content: [{ type: "text", text: "Employee ID not found." }] };
    }

    const requestedDays = leave_dates.length;
    const availableBalance = employeeLeaves[employee_id].balance;

    if (availableBalance < requestedDays) {
      return {
        content: [
          {
            type: "text",
            text: `Insufficient leave balance. You requested ${requestedDays} day(s) but have only ${availableBalance}.`,
          },
        ],
      };
    }

    employeeLeaves[employee_id].balance -= requestedDays;
    employeeLeaves[employee_id].history.push(...leave_dates);

    return {
      content: [
        {
          type: "text",
          text: `Leave applied for ${requestedDays} day(s). Remaining balance: ${employeeLeaves[employee_id].balance}.`,
        },
      ],
    };
  }
);

// Tool: Leave history
mcp.tool(
  "get_leave_history",
  "Get leave history for the employee",
  {
    employee_id: z.string(),
  },
  async ({ employee_id }) => {
    const data = employeeLeaves[employee_id];
    if (!data) {
      return { content: [{ type: "text", text: "Employee ID not found." }] };
    }
    const history = data.history.length ? data.history.join(", ") : "No leaves taken.";
    return {
      content: [{ type: "text", text: `Leave history for ${employee_id}: ${history}` }],
    };
  }
);

// Resource: Greeting
mcp.resource(
  "greeting",
  new ResourceTemplate("greeting://{name}", { list: undefined }),
  async (uri, { name }) => ({
    contents: [
      {
        uri: uri.href,
        text: `Hello, ${name}! How can I assist you with leave management today?`,
      },
    ],
  })
);

// Start server
const transport = new StdioServerTransport();
await mcp.connect(transport);